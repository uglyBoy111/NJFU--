import router from '@ohos:router';
//起始日期
import { now_week } from '@bundle:com.example.teamwork/entry/ets/pages/My_Time';
let week_select_xiaoli = now_week;
function __Button__fancyButton(isOn) {
    Button.width(60);
    Button.height(45);
    Button.backgroundColor(isOn ? '#33AFFF' : '#909497');
    Button.borderRadius(15);
    Button.margin(8);
}
function navItem01(parent = null) {
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Scroll.create();
        Scroll.debugLine("pages/xiaoli.ets(17:3)");
        Scroll.width('100%');
        Scroll.height('140%');
        Scroll.scrollable(ScrollDirection.Vertical);
        if (!isInitialRender) {
            Scroll.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/xiaoli.ets(18:5)");
        Column.backgroundImage({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Column.width('100%');
        Column.height('100%');
        Column.backgroundImagePosition(Alignment.Center);
        Column.backgroundImageSize(ImageSize.Cover);
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Row.create();
        Row.debugLine("pages/xiaoli.ets(19:7)");
        if (!isInitialRender) {
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('南京林业大学校历');
        Text.debugLine("pages/xiaoli.ets(20:9)");
        Text.fontSize(30);
        Text.fontWeight(FontWeight.Medium);
        Text.margin({ top: 8 });
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Row.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Scroll.create();
        Scroll.debugLine("pages/xiaoli.ets(27:7)");
        Scroll.width('100%');
        Scroll.height(300);
        Scroll.scrollable(ScrollDirection.Horizontal);
        if (!isInitialRender) {
            Scroll.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Row.create();
        Row.debugLine("pages/xiaoli.ets(28:9)");
        if (!isInitialRender) {
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Image.create({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Image.debugLine("pages/xiaoli.ets(29:11)");
        Image.margin({
            top: 15,
            left: 5
        });
        if (!isInitialRender) {
            Image.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Row.pop();
    Scroll.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create({ space: 5 });
        Column.debugLine("pages/xiaoli.ets(40:7)");
        Column.alignItems(HorizontalAlign.Start);
        Column.margin({
            top: 5
        });
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('1、全校学生8月31、9月1日注册报到，9月2日正式上课');
        Text.debugLine("pages/xiaoli.ets(41:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('2、每周星期三下午7-8节课学校集中安排活动时段。');
        Text.debugLine("pages/xiaoli.ets(42:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('3、国庆节、中秋节、元旦放假见校办通知。');
        Text.debugLine("pages/xiaoli.ets(43:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('4、寒假：2025年元月13日～2月16日。 ');
        Text.debugLine("pages/xiaoli.ets(44:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('5、上课时间表：');
        Text.debugLine("pages/xiaoli.ets(45:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Column.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Swiper.create();
        Swiper.debugLine("pages/xiaoli.ets(52:7)");
        Swiper.width('100%');
        Swiper.margin(5);
        if (!isInitialRender) {
            Swiper.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Image.debugLine("pages/xiaoli.ets(53:9)");
        if (!isInitialRender) {
            Image.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Image.debugLine("pages/xiaoli.ets(55:9)");
        if (!isInitialRender) {
            Image.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Swiper.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Row.create();
        Row.debugLine("pages/xiaoli.ets(59:7)");
        Row.width('100%');
        if (!isInitialRender) {
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('学期周数显示');
        Text.debugLine("pages/xiaoli.ets(61:9)");
        Text.textAlign(TextAlign.Center);
        Text.width('100%');
        Text.padding(6);
        Text.fontSize(20);
        Text.fontWeight(FontWeight.Bold);
        Text.margin(5);
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Row.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        // .backgroundColor(Color.Pink)
        Grid.create();
        Grid.debugLine("pages/xiaoli.ets(73:7)");
        // .backgroundColor(Color.Pink)
        Grid.columnsTemplate('1fr,1fr,1fr,1fr');
        // .backgroundColor(Color.Pink)
        Grid.rowsTemplate('1fr,1fr,1fr,1fr,1fr');
        if (!isInitialRender) {
            // .backgroundColor(Color.Pink)
            Grid.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        ForEach.create();
        const forEachItemGenFunction = (_item, index) => {
            const item = _item;
            {
                const isLazyCreate = true && (Grid.willUseProxy() === true);
                const itemCreation = (elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    GridItem.create(deepRenderFunction, isLazyCreate);
                    GridItem.debugLine("pages/xiaoli.ets(75:11)");
                    if (!isInitialRender) {
                        GridItem.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                };
                const observedShallowRender = () => {
                    this.observeComponentCreation(itemCreation);
                    GridItem.pop();
                };
                const observedDeepRender = () => {
                    this.observeComponentCreation(itemCreation);
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/xiaoli.ets(76:13)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel(`${item}`);
                        Button.debugLine("pages/xiaoli.ets(77:15)");
                        __Button__fancyButton(item == now_week);
                        Button.onClick(() => {
                            week_select_xiaoli = index + 1;
                            router.pushUrl({
                                url: 'pages/TimeTable'
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Column.pop();
                    GridItem.pop();
                };
                const deepRenderFunction = (elmtId, isInitialRender) => {
                    itemCreation(elmtId, isInitialRender);
                    this.updateFuncByElmtId.set(elmtId, itemCreation);
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/xiaoli.ets(76:13)");
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithLabel(`${item}`);
                        Button.debugLine("pages/xiaoli.ets(77:15)");
                        __Button__fancyButton(item == now_week);
                        Button.onClick(() => {
                            week_select_xiaoli = index + 1;
                            router.pushUrl({
                                url: 'pages/TimeTable'
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                    Column.pop();
                    GridItem.pop();
                };
                if (isLazyCreate) {
                    observedShallowRender();
                }
                else {
                    observedDeepRender();
                }
            }
        };
        (parent ? parent : this).forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], forEachItemGenFunction, undefined, true, false);
        if (!isInitialRender) {
            ForEach.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    ForEach.pop();
    // .backgroundColor(Color.Pink)
    Grid.pop();
    Column.pop();
    Scroll.pop();
}
export { navItem01 };
class Xiaoli extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__week = new ObservedPropertyObjectPU([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], this, "week");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.week !== undefined) {
            this.week = params.week;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__week.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__week.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get week() {
        return this.__week.get();
    }
    set week(newValue) {
        this.__week.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/xiaoli.ets(111:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        navItem01.bind(this)();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export { week_select_xiaoli };
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Xiaoli(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=xiaoli.js.map