//教室
let Classrooms = ['2101', '2102', '2103', '2104',
    '2105', '2106', '2107', '2108',
    '2109', '2110', '2201', '2202',
    '2203', '2204', '2205', '2206',];
//创建课程实例
let English = {
    name: '英语',
    time: {
        week: [1, 2, 3, 4, 5, 6, 7, 8],
        day: 3,
        Start_order: 5,
        End_order: 6
    },
    classroom: Classrooms[0] //2101
};
let Database = {
    name: '数据库原理与应用',
    time: {
        week: [1, 2, 3, 4, 5, 6],
        day: 5,
        Start_order: 1,
        End_order: 4
    },
    classroom: Classrooms[4] //2105
};
let advanced_math = {
    name: '高等数学',
    time: {
        week: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
        day: 4,
        Start_order: 1,
        End_order: 2
    },
    classroom: Classrooms[4] //2105
};
let linear_algebra = {
    name: '线性代数',
    time: {
        week: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        day: 3,
        Start_order: 5,
        End_order: 6
    },
    classroom: Classrooms[4] //2105
};
//课程
let courses = [English, Database, advanced_math, linear_algebra];
export { courses };
export { Classrooms };
//# sourceMappingURL=Lessons.js.map