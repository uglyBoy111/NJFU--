import { now_week, now_day, now_order } from '@bundle:com.example.teamwork/entry/ets/pages/My_Time';
import { courses, Classrooms } from '@bundle:com.example.teamwork/entry/ets/pages/My_Lessons';
let weeks = ['日', '一', '二', '三', '四', '五', '六'];
// 假设 p 是一个常量，指向 Classrooms 数组
const p = Classrooms;
function search(now_week, now_day, now_order) {
    // 创建一个空教室数组的副本
    let Empty_Classroom = JSON.parse(JSON.stringify(p));
    // for 遍历所有课程和所有教室进行对比
    for (let i = 0; i < Empty_Classroom.length; i++) {
        for (let j = 0; j < Empty_Classroom[i].floors.length; j++) {
            for (let k = 0; k < Empty_Classroom[i].floors[j].rooms.length; k++) {
                for (let l = 0; l < courses.length; l++) {
                    if (Empty_Classroom[i].floors[j].rooms[k] === courses[l].classroom
                        && Empty_Classroom[i].name === courses[l].teaching_building
                        && Empty_Classroom[i].floors[j].index === courses[l].floor
                        && courses[l].time.week.includes(now_week)
                        && now_day === courses[l].time.day
                        && now_order >= courses[l].time.Start_order
                        && now_order <= courses[l].time.End_order) {
                        // 使用 filter 方法创建一个不包含特定教室的新数组
                        Empty_Classroom[i].floors[j].rooms = Empty_Classroom[i].floors[j].rooms.filter(item => item !== courses[l].classroom);
                    }
                }
            }
        }
    }
    // 返回副本数组，而不是原始的 Empty_Classroom 数组
    return Empty_Classroom;
}
class Search_Ability extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__select_week = new ObservedPropertySimplePU(now_week, this, "select_week");
        this.__select_day = new ObservedPropertySimplePU(now_day, this, "select_day");
        this.__select_order = new ObservedPropertySimplePU(now_order, this, "select_order");
        this.__empty_classrooms = new ObservedPropertyObjectPU(search(this.select_week, this.select_day, this.select_order), this, "empty_classrooms");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.select_week !== undefined) {
            this.select_week = params.select_week;
        }
        if (params.select_day !== undefined) {
            this.select_day = params.select_day;
        }
        if (params.select_order !== undefined) {
            this.select_order = params.select_order;
        }
        if (params.empty_classrooms !== undefined) {
            this.empty_classrooms = params.empty_classrooms;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__select_week.purgeDependencyOnElmtId(rmElmtId);
        this.__select_day.purgeDependencyOnElmtId(rmElmtId);
        this.__select_order.purgeDependencyOnElmtId(rmElmtId);
        this.__empty_classrooms.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__select_week.aboutToBeDeleted();
        this.__select_day.aboutToBeDeleted();
        this.__select_order.aboutToBeDeleted();
        this.__empty_classrooms.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get select_week() {
        return this.__select_week.get();
    }
    set select_week(newValue) {
        this.__select_week.set(newValue);
    }
    get select_day() {
        return this.__select_day.get();
    }
    set select_day(newValue) {
        this.__select_day.set(newValue);
    }
    get select_order() {
        return this.__select_order.get();
    }
    set select_order(newValue) {
        this.__select_order.set(newValue);
    }
    get empty_classrooms() {
        return this.__empty_classrooms.get();
    }
    set empty_classrooms(newValue) {
        this.__empty_classrooms.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Search_Ability.ets(43:5)");
            Column.backgroundImage({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Column.backgroundImageSize(ImageSize.Cover);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //下拉选择框行
            Row.create();
            Row.debugLine("pages/Search_Ability.ets(45:7)");
            //下拉选择框行
            Row.justifyContent(FlexAlign.SpaceBetween);
            //下拉选择框行
            Row.width('90%');
            //下拉选择框行
            Row.margin({
                left: 18
            });
            if (!isInitialRender) {
                //下拉选择框行
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create([
                { value: '第1周', icon: "/common/public_icon.svg" },
                { value: '第2周', icon: "/common/public_icon.svg" },
                { value: '第3周', icon: "/common/public_icon.svg" },
                { value: '第4周', icon: "/common/public_icon.svg" },
                { value: '第5周', icon: "/common/public_icon.svg" },
                { value: '第6周', icon: "/common/public_icon.svg" },
                { value: '第7周', icon: "/common/public_icon.svg" },
                { value: '第8周', icon: "/common/public_icon.svg" },
                { value: '第9周', icon: "/common/public_icon.svg" },
                { value: '第10周', icon: "/common/public_icon.svg" },
                { value: '第11周', icon: "/common/public_icon.svg" },
                { value: '第12周', icon: "/common/public_icon.svg" },
                { value: '第13周', icon: "/common/public_icon.svg" },
                { value: '第14周', icon: "/common/public_icon.svg" },
                { value: '第15周', icon: "/common/public_icon.svg" },
                { value: '第16周', icon: "/common/public_icon.svg" },
                { value: '第17周', icon: "/common/public_icon.svg" },
                { value: '第18周', icon: "/common/public_icon.svg" },
                { value: '第19周', icon: "/common/public_icon.svg" },
                { value: '第20周', icon: "/common/public_icon.svg" }
            ]);
            Select.debugLine("pages/Search_Ability.ets(46:9)");
            Select.selected(2);
            Select.value(`第${now_week}周`);
            Select.font({ size: 16, weight: 500 });
            Select.fontColor('#182431');
            Select.selectedOptionFont({ size: 16, weight: 400 });
            Select.optionFont({ size: 16, weight: 400 });
            Select.onSelect((index) => {
                this.select_week = index + 1;
                this.empty_classrooms = search(this.select_week, this.select_day, this.select_order);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create([
                { value: '周一', icon: "/common/public_icon.svg" },
                { value: '周二', icon: "/common/public_icon.svg" },
                { value: '周三', icon: "/common/public_icon.svg" },
                { value: '周四', icon: "/common/public_icon.svg" },
                { value: '周五', icon: "/common/public_icon.svg" },
                { value: '周六', icon: "/common/public_icon.svg" },
                { value: '周日', icon: "/common/public_icon.svg" }
            ]);
            Select.debugLine("pages/Search_Ability.ets(78:9)");
            Select.selected(2);
            Select.value(`周${weeks[now_day]}`);
            Select.font({ size: 16, weight: 500 });
            Select.fontColor('#182431');
            Select.selectedOptionFont({ size: 16, weight: 400 });
            Select.optionFont({ size: 16, weight: 400 });
            Select.onSelect((index) => {
                this.select_day = index + 1;
                this.empty_classrooms = search(this.select_week, this.select_day, this.select_order);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create([
                { value: '第1节课', icon: "/common/public_icon.svg" },
                { value: '第2节课', icon: "/common/public_icon.svg" },
                { value: '第3节课', icon: "/common/public_icon.svg" },
                { value: '第4节课', icon: "/common/public_icon.svg" },
                { value: '第5节课', icon: "/common/public_icon.svg" },
                { value: '第6节课', icon: "/common/public_icon.svg" },
                { value: '第7节课', icon: "/common/public_icon.svg" },
                { value: '第8节课', icon: "/common/public_icon.svg" },
                { value: '第9节课', icon: "/common/public_icon.svg" },
                { value: '第10节课', icon: "/common/public_icon.svg" },
                { value: '第11节课', icon: "/common/public_icon.svg" }
            ]);
            Select.debugLine("pages/Search_Ability.ets(98:9)");
            Select.selected(2);
            Select.value(`${now_order ? ('第' + now_order + '节课') : '未上课'}`);
            Select.font({ size: 16, weight: 500 });
            Select.fontColor('#182431');
            Select.selectedOptionFont({ size: 16, weight: 400 });
            Select.optionFont({ size: 16, weight: 400 });
            Select.onSelect((index) => {
                this.select_order = index + 1;
                this.empty_classrooms = search(this.select_week, this.select_day, this.select_order);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        //下拉选择框行
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Search_Ability.ets(127:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('此时段空教室如下：');
            Text.debugLine("pages/Search_Ability.ets(128:9)");
            Text.margin({
                top: 30,
                bottom: 10
            });
            Text.fontSize(30);
            Text.fontStyle(FontStyle.Italic);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Search_Ability.ets(136:9)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.margin({
                left: 30,
                right: 30
            });
            Row.padding(50);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index_i) => {
                const item1 = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Column.create();
                    Column.debugLine("pages/Search_Ability.ets(138:13)");
                    Column.align(Alignment.Top);
                    Column.width('50%');
                    Column.height('100%');
                    if (!isInitialRender) {
                        Column.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(this.empty_classrooms[index_i].name);
                    Text.debugLine("pages/Search_Ability.ets(139:15)");
                    Text.fontSize(25);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    ForEach.create();
                    const forEachItemGenFunction = (_item, index_j) => {
                        const item2 = _item;
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            ForEach.create();
                            const forEachItemGenFunction = (_item, index_k) => {
                                const item3 = _item;
                                this.observeComponentCreation((elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    Text.create(`${this.empty_classrooms[index_i].floors[index_j].index}楼${this.empty_classrooms[index_i].floors[index_j].rooms[index_k]}`);
                                    Text.debugLine("pages/Search_Ability.ets(144:19)");
                                    Text.fontSize(18);
                                    if (!isInitialRender) {
                                        Text.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                });
                                Text.pop();
                            };
                            this.forEachUpdateFunction(elmtId, this.empty_classrooms[index_i].floors[index_j].rooms, forEachItemGenFunction, undefined, true, false);
                            if (!isInitialRender) {
                                ForEach.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        ForEach.pop();
                    };
                    this.forEachUpdateFunction(elmtId, this.empty_classrooms[index_i].floors, forEachItemGenFunction, undefined, true, false);
                    if (!isInitialRender) {
                        ForEach.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                ForEach.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.empty_classrooms, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Search_Ability(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Search_Ability.js.map