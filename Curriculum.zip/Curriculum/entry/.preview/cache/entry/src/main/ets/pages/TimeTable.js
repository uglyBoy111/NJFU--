import router from '@ohos:router';
import { courses } from '@bundle:com.example.teamwork/entry/ets/pages/My_Lessons';
import { week_select_xiaoli } from '@bundle:com.example.teamwork/entry/ets/pages/xiaoli';
import { Classrooms } from '@bundle:com.example.teamwork/entry/ets/pages/My_Lessons';
let rooms = ['1101', '1102', '1103', '1104', '1105', '1106',
    '2101', '2102', '2103', '2104', '2105', '2106',
    '5101', '5102', '5103', '5104', '5105', '5106',
    '5101', '5102', '5103', '5104', '5105', '5106'];
function getfontColor(index, startOrder) {
    let color = '#000000';
    if (index != (startOrder - 1)) {
        color += '00'; // 完全不显示
    }
    return color;
}
//课程随机颜色函数
function getRandomColor(index, startOrder) {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 13 + 2)];
    }
    if (index != (startOrder - 1)) {
        color += '000'; // 此处将透明度设置为00无效，于是设置000超出8位使得完全不显示背景色
    }
    else {
        color += 'A4';
    }
    return color;
}
const courseColorMap = new Map();
function getDurationHeight(index, endOrder) {
    const duration = endOrder - index;
    return `${duration * 250}px`; // 根据每节课的高度计算总高度
}
export { navItem02 };
function navItem02(now_week, Classrooms, parent = null) {
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/TimeTable.ets(44:3)");
        Column.height('100%');
        Column.width('100%');
        Column.backgroundImage({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Column.backgroundImagePosition(Alignment.Center);
        Column.backgroundImageSize(ImageSize.Cover);
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        // 顶部组件
        Row.create();
        Row.debugLine("pages/TimeTable.ets(46:5)");
        // 顶部组件
        Row.width('100%');
        // 顶部组件
        Row.justifyContent(FlexAlign.SpaceBetween);
        // 顶部组件
        Row.backgroundColor(Color.White);
        if (!isInitialRender) {
            // 顶部组件
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Select.create([
            { value: '教学主楼', icon: "/common/public_icon.svg" },
            { value: '教学五楼', icon: "/common/public_icon.svg" },
        ]);
        Select.debugLine("pages/TimeTable.ets(47:7)");
        Select.selected(2);
        Select.value('教学楼');
        Select.font({ size: 16, weight: 500 });
        Select.fontColor('#182431');
        Select.selectedOptionFont({ size: 16, weight: 400 });
        Select.optionFont({ size: 16, weight: 400 });
        Select.onSelect((index) => {
            this.teaching_building_index = index;
            this.rooms_index = -1;
        });
        if (!isInitialRender) {
            Select.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Select.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/TimeTable.ets(61:7)");
        Column.margin({
            top: 5
        });
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create(`第${now_week}周`);
        Text.debugLine("pages/TimeTable.ets(62:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create('2023-2024第二学期');
        Text.debugLine("pages/TimeTable.ets(63:9)");
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Column.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        If.create();
        if (this.teaching_building_index == 0) {
            (parent ? parent : this).ifElseBranchUpdateFunction(0, () => {
                (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Select.create([
                        { value: '1楼1101', icon: "/common/public_icon.svg" },
                        { value: '1楼1102', icon: "/common/public_icon.svg" },
                        { value: '1楼1103', icon: "/common/public_icon.svg" },
                        { value: '1楼1104', icon: "/common/public_icon.svg" },
                        { value: '1楼1105', icon: "/common/public_icon.svg" },
                        { value: '2楼1106', icon: "/common/public_icon.svg" },
                        { value: '2楼2101', icon: "/common/public_icon.svg" },
                        { value: '2楼2102', icon: "/common/public_icon.svg" },
                        { value: '2楼2103', icon: "/common/public_icon.svg" },
                        { value: '2楼2104', icon: "/common/public_icon.svg" },
                        { value: '2楼2105', icon: "/common/public_icon.svg" },
                        { value: '2楼2106', icon: "/common/public_icon.svg" }
                    ]);
                    Select.debugLine("pages/TimeTable.ets(69:9)");
                    Select.selected(2);
                    Select.value('教室');
                    Select.font({ size: 16, weight: 500 });
                    Select.fontColor('#182431');
                    Select.selectedOptionFont({ size: 16, weight: 400 });
                    Select.optionFont({ size: 16, weight: 400 });
                    Select.onSelect((index) => {
                        this.rooms_index = index;
                    });
                    if (!isInitialRender) {
                        Select.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Select.pop();
            });
        }
        else if (this.teaching_building_index == 1) {
            (parent ? parent : this).ifElseBranchUpdateFunction(1, () => {
                (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Select.create([
                        { value: '1楼5101', icon: "/common/public_icon.svg" },
                        { value: '1楼5102', icon: "/common/public_icon.svg" },
                        { value: '1楼5103', icon: "/common/public_icon.svg" },
                        { value: '1楼5104', icon: "/common/public_icon.svg" },
                        { value: '1楼5105', icon: "/common/public_icon.svg" },
                        { value: '2楼5106', icon: "/common/public_icon.svg" },
                        { value: '2楼5101', icon: "/common/public_icon.svg" },
                        { value: '2楼5102', icon: "/common/public_icon.svg" },
                        { value: '2楼5103', icon: "/common/public_icon.svg" },
                        { value: '2楼5104', icon: "/common/public_icon.svg" },
                        { value: '2楼5105', icon: "/common/public_icon.svg" },
                        { value: '2楼5106', icon: "/common/public_icon.svg" }
                    ]);
                    Select.debugLine("pages/TimeTable.ets(94:9)");
                    Select.selected(2);
                    Select.value('教室');
                    Select.font({ size: 16, weight: 500 });
                    Select.fontColor('#182431');
                    Select.selectedOptionFont({ size: 16, weight: 400 });
                    Select.optionFont({ size: 16, weight: 400 });
                    Select.onSelect((index) => {
                        this.rooms_index = index;
                    });
                    if (!isInitialRender) {
                        Select.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Select.pop();
            });
        }
        else {
            this.ifElseBranchUpdateFunction(2, () => {
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Select.create([
                        { value: '请先选择教学楼', icon: "/common/public_icon.svg" }
                    ]);
                    Select.debugLine("pages/TimeTable.ets(119:9)");
                    Select.selected(2);
                    Select.value('教室');
                    Select.font({ size: 16, weight: 500 });
                    Select.fontColor('#182431');
                    Select.selectedOptionFont({ size: 16, weight: 400 });
                    Select.optionFont({ size: 16, weight: 400 });
                    if (!isInitialRender) {
                        Select.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Select.pop();
            });
        }
        if (!isInitialRender) {
            If.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    If.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/TimeTable.ets(129:7)");
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Image.create({ "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
        Image.debugLine("pages/TimeTable.ets(130:9)");
        Image.width(25);
        Image.margin(12);
        Image.onClick(() => {
            router.pushUrl({
                url: 'pages/Search_Ability'
            });
        });
        if (!isInitialRender) {
            Image.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Column.pop();
    // 顶部组件
    Row.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        // 添加周一到周日
        Row.create();
        Row.debugLine("pages/TimeTable.ets(145:5)");
        // 添加周一到周日
        Row.width('100%');
        // 添加周一到周日
        Row.padding(10);
        // 添加周一到周日
        Row.backgroundColor('#D3D3D3');
        // 添加周一到周日
        Row.margin({
            bottom: 10
        });
        if (!isInitialRender) {
            // 添加周一到周日
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/TimeTable.ets(146:7)");
        Column.width('15%');
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Column.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        ForEach.create();
        const forEachItemGenFunction = _item => {
            const day = _item;
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                Column.create();
                Column.debugLine("pages/TimeTable.ets(148:9)");
                Column.width('12%');
                if (!isInitialRender) {
                    Column.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                Text.create(day);
                Text.debugLine("pages/TimeTable.ets(149:11)");
                Text.fontSize(14);
                Text.textAlign(TextAlign.Center);
                if (!isInitialRender) {
                    Text.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            Text.pop();
            Column.pop();
        };
        (parent ? parent : this).forEachUpdateFunction(elmtId, this.daysOfWeek, forEachItemGenFunction);
        if (!isInitialRender) {
            ForEach.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    ForEach.pop();
    // 添加周一到周日
    Row.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        // Scroll组件
        Scroll.create();
        Scroll.debugLine("pages/TimeTable.ets(163:5)");
        // Scroll组件
        Scroll.height('100%');
        // Scroll组件
        Scroll.width('100%');
        if (!isInitialRender) {
            // Scroll组件
            Scroll.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/TimeTable.ets(164:7)");
        Column.height('132%');
        Column.width('100%');
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        // 显示时间段和课程
        ForEach.create();
        const forEachItemGenFunction = (_item, index) => {
            const timeSlot = _item;
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                Row.create();
                Row.debugLine("pages/TimeTable.ets(167:11)");
                Row.width('100%');
                Row.height(85);
                Row.padding(5);
                if (!isInitialRender) {
                    Row.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                // 时间段
                Column.create();
                Column.debugLine("pages/TimeTable.ets(169:13)");
                // 时间段
                Column.width('15%');
                // 时间段
                Column.height(85);
                // 时间段
                Column.padding(5);
                if (!isInitialRender) {
                    // 时间段
                    Column.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                Text.create(`${index + 1}`);
                Text.debugLine("pages/TimeTable.ets(170:15)");
                Text.fontSize(12);
                Text.textAlign(TextAlign.Center);
                if (!isInitialRender) {
                    Text.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            Text.pop();
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                Text.create(`${timeSlot}`);
                Text.debugLine("pages/TimeTable.ets(173:15)");
                Text.fontSize(12);
                Text.textAlign(TextAlign.Center);
                if (!isInitialRender) {
                    Text.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            Text.pop();
            // 时间段
            Column.pop();
            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                // 每一天的课程
                ForEach.create();
                const forEachItemGenFunction = _item => {
                    const day = _item;
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Column.create();
                        Column.debugLine("pages/TimeTable.ets(184:15)");
                        Column.width('12%');
                        Column.height('100%');
                        if (!isInitialRender) {
                            Column.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        // 过滤出当天和当前周次的课程，
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const course = _item;
                            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Column.create();
                                Column.debugLine("pages/TimeTable.ets(196:19)");
                                Column.onClick(() => {
                                    AlertDialog.show({
                                        title: course.name,
                                        message: '课程名称' + course.name + '\n' + '上课地点:' + course.classroom + '\n' + '课程教师:' + course.teacher,
                                        autoCancel: true,
                                        alignment: DialogAlignment.Bottom,
                                        gridCount: 4,
                                        offset: { dx: 0, dy: -20 },
                                        primaryButton: {
                                            value: '取消',
                                            action: () => {
                                                console.info('Callback when the first button is clicked');
                                            }
                                        },
                                        secondaryButton: {
                                            value: '确认',
                                            action: () => {
                                                console.info('Callback when the second button is clicked');
                                            }
                                        },
                                        cancel: () => {
                                            console.info('Closed callbacks');
                                        }
                                    });
                                });
                                Column.alignItems(HorizontalAlign.Center);
                                Column.justifyContent(FlexAlign.Center);
                                Column.padding(5);
                                Column.backgroundColor(getRandomColor(index, course.time.Start_order));
                                Column.borderRadius(5);
                                Column.margin({
                                    left: 0,
                                    right: 0
                                });
                                Column.height(getDurationHeight(index, course.time.End_order));
                                if (!isInitialRender) {
                                    Column.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Text.create(`${course.name}`);
                                Text.debugLine("pages/TimeTable.ets(197:21)");
                                Text.fontColor(getfontColor(index, course.time.Start_order));
                                Text.fontSize(10);
                                Text.textAlign(TextAlign.Center);
                                Text.fontWeight(FontWeight.Bold);
                                if (!isInitialRender) {
                                    Text.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Text.pop();
                            (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Text.create(`@${course.classroom}`);
                                Text.debugLine("pages/TimeTable.ets(202:21)");
                                Text.fontSize(8);
                                Text.textAlign(TextAlign.Center);
                                Text.fontColor(getfontColor(index, course.time.Start_order));
                                if (!isInitialRender) {
                                    Text.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Text.pop();
                            Column.pop();
                        };
                        (parent ? parent : this).forEachUpdateFunction(elmtId, this.courseList.filter(course => (((course.classroom == rooms[this.teaching_building_index * 12 + this.rooms_index])
                            || (this.teaching_building_index == -1))
                            || (this.rooms_index == -1 && this.teaching_building_index != -1 && course.teaching_building == Classrooms[this.teaching_building_index].name)) &&
                            (course.time.day == day) &&
                            (course.time.week.includes(now_week)) &&
                            (course.time.Start_order - 1 <= index) &&
                            (course.time.End_order - 1 >= index)), forEachItemGenFunction);
                        if (!isInitialRender) {
                            // 过滤出当天和当前周次的课程，
                            ForEach.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    // 过滤出当天和当前周次的课程，
                    ForEach.pop();
                    Column.pop();
                };
                (parent ? parent : this).forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7], forEachItemGenFunction);
                if (!isInitialRender) {
                    // 每一天的课程
                    ForEach.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
            // 每一天的课程
            ForEach.pop();
            Row.pop();
        };
        (parent ? parent : this).forEachUpdateFunction(elmtId, this.timeSlots, forEachItemGenFunction, undefined, true, false);
        if (!isInitialRender) {
            // 显示时间段和课程
            ForEach.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    // 显示时间段和课程
    ForEach.pop();
    Column.pop();
    // Scroll组件
    Scroll.pop();
    Column.pop();
}
class TimeTable extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__lessons = new ObservedPropertyObjectPU(['第一节课', '第二节课', '第三节课', '第四节课', '第五节课', '第六节课', '第七节课', '第八节课', '第九节课', '第十节课', '第十一节课'], this, "lessons");
        this.__timeSlots = new ObservedPropertyObjectPU(['08:00-08:50', '09:00-09:50', '10:10-11:00', '11:10-12:00', '14:00-14:50', '15:00-15:50', '16:10-17:00', '17:10-18:00', '18:30-19:20', '19:30-20:20', '20:30-21:20'], this, "timeSlots");
        this.__courseList = new ObservedPropertyObjectPU(courses, this, "courseList");
        this.__daysOfWeek = new ObservedPropertyObjectPU(['周一', '周二', '周三', '周四', '周五', '周六', '周日'], this, "daysOfWeek");
        this.__current_week = new ObservedPropertySimplePU(week_select_xiaoli, this, "current_week");
        this.__teaching_building_index = new ObservedPropertySimplePU(-1, this, "teaching_building_index");
        this.__rooms_index = new ObservedPropertySimplePU(-1, this, "rooms_index");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.lessons !== undefined) {
            this.lessons = params.lessons;
        }
        if (params.timeSlots !== undefined) {
            this.timeSlots = params.timeSlots;
        }
        if (params.courseList !== undefined) {
            this.courseList = params.courseList;
        }
        if (params.daysOfWeek !== undefined) {
            this.daysOfWeek = params.daysOfWeek;
        }
        if (params.current_week !== undefined) {
            this.current_week = params.current_week;
        }
        if (params.teaching_building_index !== undefined) {
            this.teaching_building_index = params.teaching_building_index;
        }
        if (params.rooms_index !== undefined) {
            this.rooms_index = params.rooms_index;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__lessons.purgeDependencyOnElmtId(rmElmtId);
        this.__timeSlots.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__daysOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__current_week.purgeDependencyOnElmtId(rmElmtId);
        this.__teaching_building_index.purgeDependencyOnElmtId(rmElmtId);
        this.__rooms_index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__lessons.aboutToBeDeleted();
        this.__timeSlots.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__daysOfWeek.aboutToBeDeleted();
        this.__current_week.aboutToBeDeleted();
        this.__teaching_building_index.aboutToBeDeleted();
        this.__rooms_index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get lessons() {
        return this.__lessons.get();
    }
    set lessons(newValue) {
        this.__lessons.set(newValue);
    }
    get timeSlots() {
        return this.__timeSlots.get();
    }
    set timeSlots(newValue) {
        this.__timeSlots.set(newValue);
    }
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue) {
        this.__courseList.set(newValue);
    }
    get daysOfWeek() {
        return this.__daysOfWeek.get();
    }
    set daysOfWeek(newValue) {
        this.__daysOfWeek.set(newValue);
    }
    get current_week() {
        return this.__current_week.get();
    }
    set current_week(newValue) {
        this.__current_week.set(newValue);
    }
    get teaching_building_index() {
        return this.__teaching_building_index.get();
    }
    set teaching_building_index(newValue) {
        this.__teaching_building_index.set(newValue);
    }
    get rooms_index() {
        return this.__rooms_index.get();
    }
    set rooms_index(newValue) {
        this.__rooms_index.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/TimeTable.ets(279:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        navItem02.bind(this)(week_select_xiaoli, Classrooms);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TimeTable(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TimeTable.js.map