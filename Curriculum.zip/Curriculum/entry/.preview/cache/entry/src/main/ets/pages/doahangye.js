//导入课程表数据
import { navItem02 } from '@bundle:com.example.teamwork/entry/ets/pages/TimeTable';
//导入校历数据
import { navItem01 } from '@bundle:com.example.teamwork/entry/ets/pages/xiaoli';
//现在是第几节课
import { now_order } from '@bundle:com.example.teamwork/entry/ets/pages/My_Time';
//现在是周几
import { now_day } from '@bundle:com.example.teamwork/entry/ets/pages/My_Time';
//现在是第几周
import { now_week } from '@bundle:com.example.teamwork/entry/ets/pages/My_Time';
//课程类
import { Classrooms } from '@bundle:com.example.teamwork/entry/ets/pages/My_Lessons';
//课程对象数组
import { courses } from '@bundle:com.example.teamwork/entry/ets/pages/My_Lessons';
class Doahangye extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__selectIndex = new ObservedPropertySimplePU(0
        //预设课程表区域
        , this, "selectIndex");
        this.__i = new ObservedPropertyObjectPU([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], this, "i");
        this.__lessons = new ObservedPropertyObjectPU(['第一节课', '第二节课', '第三节课', '第四节课', '第五节课', '第六节课', '第七节课', '第八节课', '第九节课', '第十节课', '第十一节课'], this, "lessons");
        this.__timeSlots = new ObservedPropertyObjectPU(['08:00-08:50', '09:00-09:50', '10:10-11:00', '11:10-12:00', '14:00-14:50', '15:00-15:50', '16:10-17:00', '17:10-18:00', '18:30-19:20', '19:30-20:20', '20:30-21:20'], this, "timeSlots");
        this.__courseList = new ObservedPropertyObjectPU(courses, this, "courseList");
        this.__daysOfWeek = new ObservedPropertyObjectPU(['周一', '周二', '周三', '周四', '周五', '周六', '周日'], this, "daysOfWeek");
        this.__select_week = new ObservedPropertySimplePU(now_week, this, "select_week");
        this.__select_day = new ObservedPropertySimplePU(now_day, this, "select_day");
        this.__select_order = new ObservedPropertySimplePU(now_order, this, "select_order");
        this.__teaching_building_index = new ObservedPropertySimplePU(-1, this, "teaching_building_index");
        this.__rooms_index = new ObservedPropertySimplePU(-1, this, "rooms_index");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectIndex !== undefined) {
            this.selectIndex = params.selectIndex;
        }
        if (params.i !== undefined) {
            this.i = params.i;
        }
        if (params.lessons !== undefined) {
            this.lessons = params.lessons;
        }
        if (params.timeSlots !== undefined) {
            this.timeSlots = params.timeSlots;
        }
        if (params.courseList !== undefined) {
            this.courseList = params.courseList;
        }
        if (params.daysOfWeek !== undefined) {
            this.daysOfWeek = params.daysOfWeek;
        }
        if (params.select_week !== undefined) {
            this.select_week = params.select_week;
        }
        if (params.select_day !== undefined) {
            this.select_day = params.select_day;
        }
        if (params.select_order !== undefined) {
            this.select_order = params.select_order;
        }
        if (params.teaching_building_index !== undefined) {
            this.teaching_building_index = params.teaching_building_index;
        }
        if (params.rooms_index !== undefined) {
            this.rooms_index = params.rooms_index;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__i.purgeDependencyOnElmtId(rmElmtId);
        this.__lessons.purgeDependencyOnElmtId(rmElmtId);
        this.__timeSlots.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__daysOfWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__select_week.purgeDependencyOnElmtId(rmElmtId);
        this.__select_day.purgeDependencyOnElmtId(rmElmtId);
        this.__select_order.purgeDependencyOnElmtId(rmElmtId);
        this.__teaching_building_index.purgeDependencyOnElmtId(rmElmtId);
        this.__rooms_index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectIndex.aboutToBeDeleted();
        this.__i.aboutToBeDeleted();
        this.__lessons.aboutToBeDeleted();
        this.__timeSlots.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__daysOfWeek.aboutToBeDeleted();
        this.__select_week.aboutToBeDeleted();
        this.__select_day.aboutToBeDeleted();
        this.__select_order.aboutToBeDeleted();
        this.__teaching_building_index.aboutToBeDeleted();
        this.__rooms_index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get selectIndex() {
        return this.__selectIndex.get();
    }
    set selectIndex(newValue) {
        this.__selectIndex.set(newValue);
    }
    get i() {
        return this.__i.get();
    }
    set i(newValue) {
        this.__i.set(newValue);
    }
    get lessons() {
        return this.__lessons.get();
    }
    set lessons(newValue) {
        this.__lessons.set(newValue);
    }
    get timeSlots() {
        return this.__timeSlots.get();
    }
    set timeSlots(newValue) {
        this.__timeSlots.set(newValue);
    }
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue) {
        this.__courseList.set(newValue);
    }
    get daysOfWeek() {
        return this.__daysOfWeek.get();
    }
    set daysOfWeek(newValue) {
        this.__daysOfWeek.set(newValue);
    }
    get select_week() {
        return this.__select_week.get();
    }
    set select_week(newValue) {
        this.__select_week.set(newValue);
    }
    get select_day() {
        return this.__select_day.get();
    }
    set select_day(newValue) {
        this.__select_day.set(newValue);
    }
    get select_order() {
        return this.__select_order.get();
    }
    set select_order(newValue) {
        this.__select_order.set(newValue);
    }
    get teaching_building_index() {
        return this.__teaching_building_index.get();
    }
    set teaching_building_index(newValue) {
        this.__teaching_building_index.set(newValue);
    }
    get rooms_index() {
        return this.__rooms_index.get();
    }
    set rooms_index(newValue) {
        this.__rooms_index.set(newValue);
    }
    //自定义tab组件
    myBuilder(itemIndex, title, img, selImg, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //如果激活自己，图片和文本都需要改变样式，区分tabbar
            Column.create();
            Column.debugLine("pages/doahangye.ets(38:5)");
            if (!isInitialRender) {
                //如果激活自己，图片和文本都需要改变样式，区分tabbar
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(itemIndex == this.selectIndex ? selImg : img);
            Image.debugLine("pages/doahangye.ets(39:7)");
            Image.width(40);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/doahangye.ets(41:7)");
            Text.fontColor(itemIndex == this.selectIndex ? Color.Black : Color.Black);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //如果激活自己，图片和文本都需要改变样式，区分tabbar
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("pages/doahangye.ets(47:5)");
            Tabs.animationDuration(0);
            Tabs.scrollable(false);
            Tabs.backgroundColor('D0D1D2');
            Tabs.onChange((index) => {
                this.selectIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                navItem01.bind(this)();
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 0, '校历', { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" }, { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/doahangye.ets(50:7)");
            if (!isInitialRender) {
                //校历区域
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                navItem02.bind(this)(now_week, Classrooms);
            });
            TabContent.tabBar({ builder: () => {
                    this.myBuilder.call(this, 1, '课程表', { "id": 16777224, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" }, { "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
                } });
            TabContent.debugLine("pages/doahangye.ets(56:7)");
            if (!isInitialRender) {
                //课程表区域
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Doahangye(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=doahangye.js.map