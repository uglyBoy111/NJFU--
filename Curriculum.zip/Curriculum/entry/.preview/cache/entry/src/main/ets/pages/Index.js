let users = [
    { username: '2250301410', password: '123456' },
    { username: '2250301416', password: '123456' },
    { username: 'admin', password: '123456' }
];
import router from '@ohos:router';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('111', this, "message");
        this.__MyTips = new ObservedPropertySimplePU('不会写这个功能' //提示我不会写的状态变量
        //账号密码
        , this, "MyTips");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU(''
        //构建界面
        , this, "password");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.MyTips !== undefined) {
            this.MyTips = params.MyTips;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__MyTips.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__MyTips.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get MyTips() {
        return this.__MyTips.get();
    }
    set MyTips(newValue) {
        this.__MyTips.set(newValue);
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    //构建界面
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/Index.ets(24:5)");
            Column.padding(15);
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //统一身份认证
            Row.create();
            Row.debugLine("pages/Index.ets(27:7)");
            //统一身份认证
            Row.justifyContent(FlexAlign.SpaceBetween);
            //统一身份认证
            Row.width('100%');
            //统一身份认证
            Row.height(40);
            //统一身份认证
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                //统一身份认证
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(28:9)");
            Image.width(23);
            Image.fillColor('#111');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('统一身份认证');
            Text.debugLine("pages/Index.ets(31:9)");
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(18);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(34:9)");
            Image.width(21);
            Image.fillColor('#111');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //统一身份认证
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //校徽
            Image.create({ "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(44:7)");
            //校徽
            Image.height(150);
            //校徽
            Image.margin({
                bottom: 8,
                top: 5
            });
            if (!isInitialRender) {
                //校徽
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Swiper.create();
            Swiper.debugLine("pages/Index.ets(51:7)");
            Swiper.loop(true);
            Swiper.autoPlay(true);
            Swiper.interval(1300);
            Swiper.indicator(false);
            if (!isInitialRender) {
                Swiper.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('欢迎登录');
            Text.debugLine("pages/Index.ets(52:9)");
            Text.margin({
                bottom: 25
            });
            Text.fontColor('#666');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('梁川川');
            Text.debugLine("pages/Index.ets(57:9)");
            Text.margin({
                bottom: 25,
                left: 9
            });
            Text.fontColor('#666');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('时海鹏');
            Text.debugLine("pages/Index.ets(63:9)");
            Text.margin({
                bottom: 25,
                left: 9
            });
            Text.fontColor('#666');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('刘笑天');
            Text.debugLine("pages/Index.ets(69:9)");
            Text.margin({
                bottom: 25,
                left: 9
            });
            Text.fontColor('#666');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('马俊杰');
            Text.debugLine("pages/Index.ets(75:9)");
            Text.margin({
                bottom: 25,
                left: 9
            });
            Text.fontColor('#666');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Swiper.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //账号密码输入
            TextInput.create({
                placeholder: '请输入用户名'
            });
            TextInput.debugLine("pages/Index.ets(88:7)");
            //账号密码输入
            TextInput.type(InputType.Normal);
            //账号密码输入
            TextInput.onChange((value) => {
                this.username = value;
            });
            if (!isInitialRender) {
                //账号密码输入
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '请输入密码'
            });
            TextInput.debugLine("pages/Index.ets(95:7)");
            TextInput.type(InputType.Password);
            TextInput.onChange((value) => {
                this.password = value;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //登录按钮
            Button.createWithLabel('登录');
            Button.debugLine("pages/Index.ets(104:7)");
            //登录按钮
            Button.onClick(() => {
                let i = 0;
                //for循环遍历用户名查找是否有匹配值
                for (i; i < users.length; i++) {
                    //console.log(this.username,this.password)
                    if ((users[i].username == this.username)
                        && (users[i].password == this.password)) {
                        router.pushUrl({
                            url: 'pages/doahangye'
                        });
                    }
                    if ((i == users.length - 1)
                        && ((users[i].username != this.username)
                            || (users[i].password != this.password))) {
                        AlertDialog.show({ message: '用户名或密码错误' });
                    }
                }
            });
            //登录按钮
            Button.width('100%');
            //登录按钮
            Button.colorBlend(Color.Green);
            if (!isInitialRender) {
                //登录按钮
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //登录按钮
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //注册、忘记密码
            Row.create({ space: 10 });
            Row.debugLine("pages/Index.ets(128:7)");
            //注册、忘记密码
            Row.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                //注册、忘记密码
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('前往注册');
            Text.debugLine("pages/Index.ets(129:9)");
            Text.margin({
                right: 5
            });
            Text.fontColor('#00bfff');
            Text.onClick(() => {
                AlertDialog.show({ message: '还没有写' });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('忘记密码');
            Text.debugLine("pages/Index.ets(137:9)");
            Text.fontColor('#00bfff');
            Text.onClick(() => {
                AlertDialog.show({ message: '还没有写' });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //注册、忘记密码
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //其它方式登录
            Blank.create();
            Blank.debugLine("pages/Index.ets(146:7)");
            if (!isInitialRender) {
                //其它方式登录
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //其它方式登录
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('-----------您还可以使用以下登录方式------------');
            Text.debugLine("pages/Index.ets(147:7)");
            Text.fontSize(12);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#666');
            Text.margin({
                bottom: 25
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(154:7)");
            Row.margin({
                bottom: 15
            });
            Row.width('50%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //QQ登录
            Column.create();
            Column.debugLine("pages/Index.ets(157:9)");
            //QQ登录
            Column.layoutWeight(1);
            if (!isInitialRender) {
                //QQ登录
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(158:11)");
            Image.width(30);
            Image.onClick(() => {
                AlertDialog.show({ message: '还没有写' });
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('QQ登录');
            Text.debugLine("pages/Index.ets(163:11)");
            Text.fontSize(13);
            Text.margin({
                left: 2
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //QQ登录
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //访客登录
            Column.create();
            Column.debugLine("pages/Index.ets(172:9)");
            //访客登录
            Column.layoutWeight(1);
            if (!isInitialRender) {
                //访客登录
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.teamwork", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(173:11)");
            Image.width(33);
            Image.onClick(() => {
                AlertDialog.show({ message: '还没有写' });
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('访客登录');
            Text.debugLine("pages/Index.ets(178:11)");
            Text.fontSize(13);
            Text.margin({
                left: 1,
                top: 1
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //访客登录
        Column.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map